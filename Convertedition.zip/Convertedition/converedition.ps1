﻿<# This form was created using POSHGUI.com  a free online gui designer for PowerShell
.NAME
    Untitled
#>

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$Form                            = New-Object system.Windows.Forms.Form
$Form.ClientSize                 = '800,600'
$Form.text                       = "Form"
$Form.TopMost                    = $false

$GetcurrentVersion               = New-Object system.Windows.Forms.Label
$GetcurrentVersion.text          = "Select The Version"
$GetcurrentVersion.AutoSize      = $true
$GetcurrentVersion.width         = 25
$GetcurrentVersion.height        = 10
$GetcurrentVersion.location      = New-Object System.Drawing.Point(6,20)
$GetcurrentVersion.Font          = 'Microsoft Sans Serif,10'

$lblcurrentversion               = New-Object system.Windows.Forms.Label
$lblcurrentversion.AutoSize      = $true
$lblcurrentversion.width         = 25
$lblcurrentversion.height        = 10
$lblcurrentversion.location      = New-Object System.Drawing.Point(146,20)
$lblcurrentversion.Font          = 'Microsoft Sans Serif,10'

$ComboBox1                       = New-Object system.Windows.Forms.ComboBox
$ComboBox1.text                  = ""
$ComboBox1.width                 = 381
$ComboBox1.height                = 200
$ComboBox1.location              = New-Object System.Drawing.Point(6,78)
$ComboBox1.Font                  = 'Microsoft Sans Serif,18'

$TextBox1                        = New-Object system.Windows.Forms.TextBox
$TextBox1.multiline              = $false
$TextBox1.width                  = 600
$TextBox1.height                 = 200
$TextBox1.location               = New-Object System.Drawing.Point(6,190)
$TextBox1.Font                   = 'Microsoft Sans Serif,18'

$Label1                          = New-Object system.Windows.Forms.Label
$Label1.text                     = "Product-key"
$Label1.AutoSize                 = $true
$Label1.width                    = 25
$Label1.height                   = 10
$Label1.location                 = New-Object System.Drawing.Point(13,143)
$Label1.Font                     = 'Microsoft Sans Serif,10'

$cmdconvert                      = New-Object system.Windows.Forms.Button
$cmdconvert.text                 = "Convert"
$cmdconvert.width                = 250
$cmdconvert.height               = 90
$cmdconvert.location             = New-Object System.Drawing.Point(6,350)
$cmdconvert.Font                 = 'Microsoft Sans Serif,10'

$Form.controls.AddRange(@($GetcurrentVersion,$lblcurrentversion,$ComboBox1,$TextBox1,$Label1,$cmdconvert))

$Form.Add_Load({  



$ComboBox1.Items.Add("ServerStandard")
$ComboBox1.Items.Add("ServerDatacenter")

})
$cmdconvert.Add_Click({ 

$ver=$ComboBox1.SelectedItem
$key=$TextBox1.Text

#Start-Process cmd -ArgumentList "/K dism /online /get-currentedition" 


start-process "cmd" -argumentlist "/K dism /online /set-edition:$ver /productkey:$key /acceptEula" -ErrorAction SilentlyContinue

})
[void]$Form.ShowDialog()
Start-Process cmd -ArgumentList